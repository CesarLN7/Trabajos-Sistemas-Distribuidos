#!/bin/bash

python3 ./client.py -s localhost -p 8080